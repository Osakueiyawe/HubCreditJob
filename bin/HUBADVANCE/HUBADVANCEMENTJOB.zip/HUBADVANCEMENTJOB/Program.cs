﻿using HUBADVANCEMENTJOB.Model;
using HUBADVANCEMENTJOB.Repo;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HUBADVANCEMENTJOB
{
    class Program
    {
        static List<HUBADVANCEREQUEST> AllHUBGUESTS;
        static ATM GetATM;
        static BASIS Basis;
  
        static void Main(string[] args)
        {
            GetATM = new ATM();
            Basis = new BASIS();
            AllHUBGUESTS = new List<HUBADVANCEREQUEST>();

            AllHUBGUESTS =  GetATM.GETALLHUBADVANCECUSTOMERS();
            var table = HubAdvanceRepaymetCalculator(AllHUBGUESTS);

            var lastDayOfMonth = DateTime.DaysInMonth(DateTime.Now.Year, DateTime.Now.Month);
            if (lastDayOfMonth == DateTime.Now.Day)
            {
                HubAdvanceRepayment(table, AllHUBGUESTS);
            }
            else
            {
                //Remove
                HubAdvanceRepayment(table, AllHUBGUESTS);
            }
            
        }

        private static void HubAdvanceRepayment(DataTable table, List<HUBADVANCEREQUEST> allHUBGUESTS)
        {
            var All = Basis.GETPREVIOUSTRANSACTION205(AllHUBGUESTS);

           Basis.CleanUpDebitRestrictionFromAdvanceToSalaryAccount(allHUBGUESTS);
            
        }

        private static DataTable HubAdvanceRepaymetCalculator(List<HUBADVANCEREQUEST> AllHUBGUESTS)
        {
            var All = Basis.GETPREVIOUSTRANSACTION(AllHUBGUESTS);
            var Modified = All.Tables[0];

            DataColumn CalculatedAmount = new DataColumn();
            CalculatedAmount.DataType = typeof(decimal);
            CalculatedAmount.DefaultValue = 0;
            CalculatedAmount.ColumnName = "CalculatedAmount";
            Modified.Columns.Add(CalculatedAmount);
            foreach (DataRow item in Modified.Rows)
            {
                if (int.Parse(item["DEB_CRE_IND"].ToString())==1)
                {
                    var Amount = decimal.Divide(1m , 12m);
                   var  TRANSACTION =  Amount * decimal.Parse(item["TRA_AMT"].ToString());
                    item["CalculatedAmount"] = Math.Round(TRANSACTION, 2, MidpointRounding.ToEven);
                }

                if (int.Parse(item["DEB_CRE_IND"].ToString()) == 2)
                {
                    var Amount = decimal.Divide(1m, 12m);
                    var TRANSACTION = Amount * decimal.Parse(item["TRA_AMT"].ToString());
                    item["CalculatedAmount"] = Math.Round(-TRANSACTION, 2, MidpointRounding.ToEven);

                }
            }
             GetATM.BulkInsert(Modified);
            return Modified;







        }

       
    }
}
