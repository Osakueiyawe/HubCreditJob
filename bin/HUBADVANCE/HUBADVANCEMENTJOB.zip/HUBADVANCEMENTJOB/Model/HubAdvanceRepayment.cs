﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HUBADVANCEMENTJOB.Model
{
   
    public class HubAdvanceRepayment
    {
        public long ID { get; set; }
        public string UNIQUEID { get; set; }
        public long CUSTOMERID { get; set; }
        public decimal? REPAYMENT_AMOUNT { get; set; }
        public string BALANCE_LIMIT_ACCOUNT { get; set; }
        public decimal? BALANCE_LIMIT_AMOUNT { get; set; }
        public string SALARY_ACCOUNT { get; set; }
        public string PENDINGSIFLAG { get; set; }
        public string REMARKS { get; set; }
    }


    public class HUBADVANCEREQUEST
    {
        public long TRANSACTIONID { get; set; }
        public string NUBAN { get; set; }
        public long? CUSTOMER_ID { get; set; }
        public DateTime? DATEINSERTED { get; set; }
        public DateTime? DATEUPDATED { get; set; }
        public string CUSTOMERNAME { get; set; }
        public string EMAIL { get; set; }
        public string PHONENUMBER { get; set; }
        public string BASIS_PHONE_NUMBER { get; set; }
        public bool? IS_ELIGIBLE { get; set; }
        public string CBN_REFERENCE { get; set; }
        public short? CBN_REF_TRYCOUNT { get; set; }
        public DateTime? CBN_REF_CHECK_DATE { get; set; }
        public string BALANCE_LIMIT_ACCOUNT { get; set; }
        public string BALANCE_LIMIT_ACCOUNT_OLDACCOUNT { get; set; }
        public decimal? BALANCE_LIMIT_AMOUNT { get; set; }
        public bool? ACTIVE { get; set; }
        public bool? ISSTAFF { get; set; }
        public string BVN { get; set; }
        public string LIMIT_STATUS { get; set; }
    }


}
