﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HUBADVANCEMENTJOB.Model;
using System.Configuration;
using System.Data;
using Oracle.ManagedDataAccess.Client;

namespace HUBADVANCEMENTJOB.Repo
{
    class BASIS
    {
        ATM GetATM;
        public BASIS()
        {
            GetATM = new ATM();
        }
        internal DataSet GETPREVIOUSTRANSACTION(List<HUBADVANCEREQUEST> allHUBGUESTS)
        {
            DataSet Maindataset = new DataSet();
            string Tradate = DateTime.Today.AddDays(-1).ToString("ddMMMyyyy");

            bool TreatOneTime = bool.Parse(ConfigurationManager.AppSettings["TreatOneTime"]);

            if (TreatOneTime)
            {
                Tradate = ConfigurationManager.AppSettings["OneOffDate"];
            }
           

            string functionReturnValue = string.Empty;
            OracleCommand cmdOraSelect = new OracleCommand();
            
            //string BraCode = string.Empty;
            //string CusNum = string.Empty;
            //foreach (var account in allHUBGUESTS)
            //{
            //    BraCode = BraCode + string.Concat("'", account.BALANCE_LIMIT_ACCOUNT_OLDACCOUNT.Split('/')[0], "'", ",");
            //    CusNum = CusNum + string.Concat("'", account.BALANCE_LIMIT_ACCOUNT_OLDACCOUNT.Split('/')[1], "'", ",");
            //}
            //int count = BraCode.Count();
            //BraCode = BraCode.Remove(count - 1);

            //count = CusNum.Count();
            //CusNum = CusNum.Remove(count - 1);

            var AccountTypes = allHUBGUESTS.GroupBy(a => a.BALANCE_LIMIT_ACCOUNT_OLDACCOUNT.Split('/')[0]).ToList();

            var NumberOfGroups = AccountTypes.Count;

            foreach (var Group in AccountTypes)
            {
                HashSet<string> CusNums = new HashSet<string>();
                foreach (var item in Group)
                {
                    CusNums.Add(item.BALANCE_LIMIT_ACCOUNT_OLDACCOUNT.Split('/')[1]);
                }

                var SQL = "select bra_code, cus_num, tra_seq1||ORIGT_TRA_SEQ1||' '||origt_tra_date||' '||UPD_TIME as UNIQUEID , DEB_CRE_IND , ACT_TRA_DATE, EXPL_CODE, TRA_AMT from transact where bra_code in (" + Group.Key + ") and cus_num in (" + String.Join(",", CusNums) + ") and tra_date >= '"+ Tradate + "' and led_code = '1010' and expl_code <> 205";
                using (OracleConnection ConnHoBank_Test = new OracleConnection(ConfigurationManager.AppSettings["BASISConString_eone"]))
                {

                    try
                    {
                        if (ConnHoBank_Test.State == ConnectionState.Closed)
                        {
                            ConnHoBank_Test.Open();
                        }

                        cmdOraSelect.Connection = ConnHoBank_Test;
                        cmdOraSelect.CommandText = SQL;
                        cmdOraSelect.CommandType = CommandType.Text;



                        using (OracleDataAdapter adapter = new OracleDataAdapter(cmdOraSelect))
                        {

                            using (DataSet dataset = new DataSet())
                            {
                                adapter.Fill(dataset, "HUBADVANCEUSERS");

                                Maindataset.Merge(dataset);
                            }
                        }



                    }
                    catch (Exception ex)
                    {


                    }
                    finally
                    {
                        if (ConnHoBank_Test.State == ConnectionState.Open)
                        {
                            ConnHoBank_Test.Close();
                        }
                    }
                    
                }

            }
            return Maindataset;

            //var SQL = "select bra_code, cus_num, tra_seq1||ORIGT_TRA_SEQ1||' '||origt_tra_date||' '||UPD_TIME as UNIQUEID , DEB_CRE_IND , ACT_TRA_DATE, EXPL_CODE, TRA_AMT from transact where bra_code in ("+BraCode+") and cus_num in ("+ CusNum + ") and tra_date >= Tradate and led_code = '1010' and expl_code <> 205";
            //using (OracleConnection ConnHoBank_Test = new OracleConnection(ConfigurationManager.AppSettings["BASISConString_eone"]))
            //{

            //    try
            //    {
            //        if (ConnHoBank_Test.State == ConnectionState.Closed)
            //        {
            //            ConnHoBank_Test.Open();
            //        }

            //        cmdOraSelect.Connection = ConnHoBank_Test;
            //        cmdOraSelect.CommandText = SQL;
            //        cmdOraSelect.CommandType = CommandType.Text;



            //        using (OracleDataAdapter adapter = new OracleDataAdapter(cmdOraSelect))
            //        {                        

            //            using (DataSet dataset = new DataSet())
            //            {
            //                adapter.Fill(dataset, "HUBADVANCEUSERS");

            //                return dataset;
            //            }
            //        }



            //    }
            //    catch (Exception ex)
            //    {


            //    }
            //    finally
            //    {
            //        if (ConnHoBank_Test.State == ConnectionState.Open)
            //        {
            //            ConnHoBank_Test.Close();
            //        }
            //    }
            //    return null;
            //}
        }

        internal void CleanUpDebitRestrictionFromAdvanceToSalaryAccount(List<HUBADVANCEREQUEST> allHUBGUESTS)
        {
            
            foreach (var AccountDetails in allHUBGUESTS)
            {
                var Amount = GetATM.GetAmoutFor(AccountDetails.CUSTOMER_ID);

                if (Amount>0)
                {
                    var Response = TransferFundWithDocAlp(AccountDetails.BALANCE_LIMIT_ACCOUNT_OLDACCOUNT.Replace("/1010/", "/1/"), AccountDetails.BALANCE_LIMIT_ACCOUNT_OLDACCOUNT, 506, Amount, "SME Hub Advance Monthly Repayment", 32);

                    if (Response.Equals("Success", StringComparison.InvariantCultureIgnoreCase))
                    {
                        var Update = GetATM.UpdateCustomerBalanceLimit(AccountDetails.CUSTOMER_ID);

                        if (Update > 0)
                        {

                        }
                    }
                    else if (Response.Equals("InsufficientBalance", StringComparison.InvariantCultureIgnoreCase))
                    {
                        var outres = PostToBasis_OverDraw(AccountDetails.BALANCE_LIMIT_ACCOUNT_OLDACCOUNT.Replace("/1010/", "/1/"), AccountDetails.BALANCE_LIMIT_ACCOUNT_OLDACCOUNT, Amount, 506, "SME Hub Advance Monthly Repayment", int.Parse(AccountDetails.TRANSACTIONID.ToString()));

                        if (outres.Equals("@ERR7@", StringComparison.InvariantCultureIgnoreCase))
                        {
                            var Update = GetATM.UpdateCustomerBalanceLimit(AccountDetails.CUSTOMER_ID);

                            if (Update > 0)
                            {

                            }
                        }
                    }
                    else
                    {

                    }
                }

            }
        }

        internal DataSet GETPREVIOUSTRANSACTION205(List<HUBADVANCEREQUEST> allHUBGUESTS)
        {
            DataSet Maindataset = new DataSet();
            string Tradate = DateTime.Today.AddDays(-1).ToString("ddMMMyyyy");

            bool TreatOneTime = bool.Parse(ConfigurationManager.AppSettings["TreatOneTime"]);

            if (TreatOneTime)
            {
                Tradate = ConfigurationManager.AppSettings["OneOffDate"];
            }


            string functionReturnValue = string.Empty;
            OracleCommand cmdOraSelect = new OracleCommand();

            var AccountTypes = allHUBGUESTS.GroupBy(a => a.BALANCE_LIMIT_ACCOUNT_OLDACCOUNT.Split('/')[0]).ToList();

            var NumberOfGroups = AccountTypes.Count;

            foreach (var Group in AccountTypes)
            {
                HashSet<string> CusNums = new HashSet<string>();
                foreach (var item in Group)
                {
                    CusNums.Add(item.BALANCE_LIMIT_ACCOUNT_OLDACCOUNT.Split('/')[1]);
                }

                var SQL = "select bra_code, cus_num, tra_seq1||ORIGT_TRA_SEQ1||' '||origt_tra_date||' '||UPD_TIME as UNIQUEID , DEB_CRE_IND , ACT_TRA_DATE, EXPL_CODE, TRA_AMT from transact where bra_code in (" + Group.Key + ") and cus_num in (" + String.Join(",", CusNums) + ") and tra_date >= '" + Tradate + "' and led_code = '1' and expl_code = 205";
                using (OracleConnection ConnHoBank_Test = new OracleConnection(ConfigurationManager.AppSettings["BASISConString_eone"]))
                {

                    try
                    {
                        if (ConnHoBank_Test.State == ConnectionState.Closed)
                        {
                            ConnHoBank_Test.Open();
                        }

                        cmdOraSelect.Connection = ConnHoBank_Test;
                        cmdOraSelect.CommandText = SQL;
                        cmdOraSelect.CommandType = CommandType.Text;



                        using (OracleDataAdapter adapter = new OracleDataAdapter(cmdOraSelect))
                        {

                            using (DataSet dataset = new DataSet())
                            {
                                adapter.Fill(dataset, "HUBADVANCEUSERS205");

                                Maindataset.Merge(dataset);
                            }
                        }



                    }
                    catch (Exception ex)
                    {


                    }
                    finally
                    {
                        if (ConnHoBank_Test.State == ConnectionState.Open)
                        {
                            ConnHoBank_Test.Close();
                        }
                    }

                }

            }
            return Maindataset;

        }





        public string TransferFunds(string accountFrom, string accountTo, int explCode, decimal amount, string remarks, int requestCode)
        {
            try
            {

                using (OracleConnection oraconn = new OracleConnection(ConfigurationManager.AppSettings["BASISConString_eone"]))
                {
                    var PostQuery = "BEGIN GTBPBSC0_FULL(:INP_ACCT_FROM, :INP_ACCT_TO, :INP_TRA_AMT, :INP_EXPL_CODE, :INP_REMARKS, :INP_RQST_CODE, :OUT_RETURN_STATUS); END;";
                    using (OracleCommand OraSelect = new OracleCommand(PostQuery, oraconn))
                    {
                        OraSelect.CommandTimeout = 20;
                        var a = new OracleParameter(":INP_ACCT_FROM", OracleDbType.Varchar2, 21, accountFrom.Trim(), ParameterDirection.Input);
                        var b = new OracleParameter(":INP_ACCT_TO", OracleDbType.Varchar2, 21, accountTo.Trim(), ParameterDirection.Input);
                        var c = new OracleParameter(":INP_TRA_AMT", OracleDbType.Double, 15, amount, ParameterDirection.Input);
                        var d = new OracleParameter(":INP_EXPL_CODE", OracleDbType.Single, 15, explCode, ParameterDirection.Input);
                        var e = new OracleParameter(":INP_REMARKS", OracleDbType.Varchar2, 200, remarks, ParameterDirection.Input);
                        var f = new OracleParameter(":INP_RQST_CODE", OracleDbType.Varchar2, 15, requestCode, ParameterDirection.Input);
                        var g = new OracleParameter(":OUT_RETURN_STATUS", OracleDbType.Varchar2, 100, null, ParameterDirection.Output);
                        OraSelect.Parameters.AddRange(new object[] { a, b, c, d, e, f, g });
                        oraconn.Open();
                        OraSelect.ExecuteNonQuery();
                        oraconn.Close();
                        string Result = OraSelect.Parameters["OUT_RETURN_STATUS"].Value.ToString();
                        if (Result == "@ERR7@" || Result == "@ERR19@")
                            return "Success";
                        else
                        {
                            return "Fail";
                        }

                    }


                    //Utility.Log().InfoFormat("Transaction was not Successful due to error {0}", retVal);
                    //return ErrorMap.ErrorMsg(retVal);
                }
                //   ts.Complete();
                //  }

                //}
            }
            catch (Exception ex)
            {

                // Utility.Log().Error("An Error occured while transferring " + ex.StackTrace, ex);
                // throw new AirtimeException("An Error occured posting transaction");
            }
            return null;
        }



        public string TransferFundWithDocAlp(string accountFrom, string accountTo, int explCode, decimal amount, string remarks, int requestCode)
        {

            if (accountFrom.Contains("/"))
            {
                accountFrom = ConvertAccountToPadded(accountFrom.Trim(), "/");
            }
            else
            {
                accountFrom = ConvertAccountOldorNUBAN(accountFrom);
                accountFrom = ConvertAccountToPadded(accountFrom.Trim(), "/");
            }


            if (accountTo.Contains("/"))
            {
                accountTo = ConvertAccountToPadded(accountTo.Trim(), "/");
            }
            else
            {
                accountTo = ConvertAccountOldorNUBAN(accountTo);
                accountTo = ConvertAccountToPadded(accountTo.Trim(), "/");
            }


            string result = "";
            string outTraSeq = "";
            string inpTraSeq = "";
            try
            {

                if (remarks.Length > 170)
                {
                    remarks = remarks.Substring(0, 170);
                }
                remarks = remarks.PadRight(170, ' ');
                remarks = remarks + DateTime.Now.Ticks;




                using (OracleConnection oraconn = new OracleConnection((ConfigurationManager.AppSettings["BASISConString_eone"])))
                {
                    if (oraconn.State == ConnectionState.Closed)
                    {
                        oraconn.Open();
                    }

                    using (OracleTransaction transaction = oraconn.BeginTransaction(IsolationLevel.ReadCommitted))
                    {

                        try
                        {
                            using (OracleCommand oracomm = oraconn.CreateCommand())
                            {
                                oracomm.CommandType = CommandType.StoredProcedure;
                                oracomm.CommandTimeout = 30;

                                //Start a local transaction and assign transaction object for a pending local transaction                
                                oracomm.Transaction = transaction;

                                oracomm.CommandText = "EONEPKG.GTBPBSC0_FULL";
                                oracomm.Parameters.Add("INP_ACCT_FROM", OracleDbType.Varchar2, 21).Value = accountFrom.Trim();
                                oracomm.Parameters.Add("INP_ACCT_TO", OracleDbType.Varchar2, 21).Value = accountTo.Trim();
                                oracomm.Parameters.Add("INP_TRA_AMT", OracleDbType.Double, 20).Value = amount;
                                oracomm.Parameters.Add("INP_EXPL_CODE", OracleDbType.Int32, 15).Value = explCode;
                                oracomm.Parameters.Add("INP_REMARKS", OracleDbType.Varchar2, 200).Value = remarks.Replace("'", "");
                                oracomm.Parameters.Add("inp_rqst_code", OracleDbType.Varchar2, 15).Value = requestCode;
                                oracomm.Parameters.Add("INP_MAN_APP1", OracleDbType.Int32, 15).Value = 0;
                                oracomm.Parameters.Add("inp_tell_id", OracleDbType.Int32, 15).Value = 9938;
                                oracomm.Parameters.Add("INP_DOC_ALP", OracleDbType.Varchar2, 200).Value = "HADV";
                                oracomm.Parameters.Add("out_tra_seq1", OracleDbType.Int32, 15).Direction = ParameterDirection.Output;
                                oracomm.Parameters.Add("inp_tra_seq1", OracleDbType.Int32, 15).Direction = ParameterDirection.Output;
                                oracomm.Parameters.Add("INP_ORIGT_BRA_CODE", OracleDbType.Int32, 15).Value = 999;
                                oracomm.Parameters.Add("out_return_status", OracleDbType.Varchar2, 100).Direction = ParameterDirection.Output;
                                if (oraconn.State == ConnectionState.Closed)
                                {
                                    oraconn.Open();
                                }
                                oracomm.ExecuteNonQuery();

                                // string result1 = oracomm.Parameters["OUT_RETURN_STATUS"].Value.ToString();


                                string returnStatus = oracomm.Parameters["OUT_RETURN_STATUS"].Value.ToString();
                               // Log.Instance.Info(returnStatus);
                                if (returnStatus.Equals("@ERR7@", StringComparison.OrdinalIgnoreCase) || returnStatus.Equals("@ERR19@", StringComparison.OrdinalIgnoreCase))
                                {
                                    outTraSeq = oracomm.Parameters["out_tra_seq1"].Value.ToString();
                                    inpTraSeq = oracomm.Parameters["inp_tra_seq1"].Value.ToString();
                                  //  Log.Instance.Info(outTraSeq);
                                  //  Log.Instance.Info(inpTraSeq);
                                    //Utility.Log()
                                    //    .InfoFormat("Basis Response: returnStatus-{0} outTraSeq-{1} inpTraSeq-{2} ",
                                    //        returnStatus, outTraSeq, inpTraSeq);

                                    transaction.Commit();
                                    return "Success";
                                }
                                else if (returnStatus.Equals("@ERR23@", StringComparison.OrdinalIgnoreCase) || returnStatus.Equals("@ERR24@", StringComparison.OrdinalIgnoreCase))
                                {

                                    transaction.Rollback();
                                    return "InsufficientBalance";
                                }
                                else
                                {
                                    transaction.Rollback();
                                    return "Failure";
                                }

                            }




                        }
                        catch (Exception ex)
                        {

                           // Log.Instance.Fatal(ex, "Error Posting to Basis for ");
                            transaction.Rollback();

                            return "";
                        }
                    }


                }


            }
            catch (Exception ex)
            {
                //Log.Instance.Fatal(ex, "An Error Occured in The Repo ");

                return "";

            }
        }


        public KeyValuePair<bool, string> GetCurrentBalance(string[] BrokenDownAccount)
        {

            // string selectquery = "select crnt_bal from account  where bra_code = :BraCode and cus_num = :CusNum and cur_code = :Curcode and led_code =  :Ledcode and sub_acct_code = :subAcctcode";

            string selectquery = "select navailbal(bra_code,cus_num, cur_code,led_code,sub_acct_code) avail_bal,crnt_bal from account where bra_code = :BraCode and cus_num = :CusNum and cur_code = :Curcode and led_code =  :Ledcode and sub_acct_code = :subAcctcode";


            bool BalanceAvailable = false;

            string ReturnMessage = "0.00:0.00";
            try
            {
                using (OracleConnection oraconn = new OracleConnection(ConfigurationManager.AppSettings["BASISConString_eone"]))
                {

                    using (OracleCommand OraSelect = new OracleCommand(selectquery, oraconn))
                    {
                        OraSelect.Parameters.Add(":BraCode", BrokenDownAccount[0]);
                        OraSelect.Parameters.Add(":CusNum", BrokenDownAccount[1]);
                        OraSelect.Parameters.Add(":CurCode", BrokenDownAccount[2]);
                        OraSelect.Parameters.Add(":LedCode", BrokenDownAccount[3]);
                        OraSelect.Parameters.Add(":SubAcctCode", BrokenDownAccount[4]);

                        OraSelect.BindByName = true;
                        oraconn.Open();
                        OraSelect.CommandText = selectquery;
                        using (OracleDataReader OraDrSelect = OraSelect.ExecuteReader())
                        {
                            if (OraDrSelect.HasRows)
                            {
                                OraDrSelect.Read();
                                BalanceAvailable = true;
                                ReturnMessage = string.Concat(OraDrSelect.GetDecimal(0).ToString("F").Trim(), ":", OraDrSelect.GetDecimal(1).ToString("F").Trim());



                            }
                            else
                            {
                                BalanceAvailable = false;


                            }
                        }

                    }

                }
            }
            catch (Exception ex)
            {
               // Log.Instance.Fatal(ex, "Could not get exception.");
                BalanceAvailable = false;

                return new KeyValuePair<bool, string>(BalanceAvailable, ReturnMessage);
            }
            return new KeyValuePair<bool, string>(BalanceAvailable, ReturnMessage);

        }


        public static string ConvertAccountToPadded(string account, string delimiter)
        {
            try
            {
                //here we accept an account bracode/cusnum.curcode/ledcode/subacctcode
                var data = account.Split(new string[] { delimiter }, StringSplitOptions.RemoveEmptyEntries);
                var bracode = data[0].PadLeft(4, '0');
                var cusnum = data[1].PadLeft(7, '0');
                var curcode = data[2].PadLeft(3, '0');
                var ledcode = data[3].PadLeft(4, '0');
                var subacctcode = data[4].PadLeft(3, '0');

                return bracode + cusnum + curcode + ledcode + subacctcode;
            }
            catch (Exception ex)
            {
                return null;
            }

        }

        public string ConvertAccountOldorNUBAN(string Account)
        {
            char acctsplit = Convert.ToChar("/");
            string[] accountkey = new string[4];// 
            string bra_code = null;
            string cus_num = null;
            string cur_code = null;
            string led_code = null;
            string sub_acct_code = null;




            OracleDataReader OraDrSelect;
            string NUBAN = null;


            try
            {
                using (OracleConnection OraConn = new OracleConnection(ConfigurationManager.AppSettings["BASISConString_eone"]))
                {


                    if (Account.Contains("/"))
                    {
                        accountkey = Account.Trim().Split(acctsplit);
                        bra_code = accountkey[0];
                        cus_num = accountkey[1];
                        cur_code = accountkey[2];
                        led_code = accountkey[3];
                        sub_acct_code = accountkey[4];

                        string selectquery = "select  MAP_ACC_NO from map_acct where bra_code = :bra_code and cus_num = :cus_num and cur_code = :cur_code and led_code = :led_code  and sub_acct_code = :sub_acct_code";
                        using (OracleCommand OraSelect = new OracleCommand())
                        {

                            OraSelect.Connection = OraConn;
                            OraSelect.CommandText = selectquery;
                            OraSelect.CommandType = CommandType.Text;
                            OraSelect.Parameters.Add(":bra_code", bra_code);
                            OraSelect.Parameters.Add(":cus_num", cus_num);
                            OraSelect.Parameters.Add(":cur_code", cur_code);
                            OraSelect.Parameters.Add(":led_code", led_code);
                            OraSelect.Parameters.Add(":sub_acct_code", sub_acct_code);
                            if (OraConn.State == ConnectionState.Closed)
                            {
                                OraConn.Open();
                            }
                            using (OraDrSelect = OraSelect.ExecuteReader(CommandBehavior.CloseConnection))
                            {
                                if (OraDrSelect.HasRows == true)
                                {
                                    OraDrSelect.Read();
                                    NUBAN = OraDrSelect["MAP_ACC_NO"].ToString();
                                  //  Log.Instance.Info(NUBAN);
                                    return NUBAN;

                                }
                                else
                                {
                                   // Log.Instance.Fatal("Cannot get nuban");
                                    return "-2";
                                }
                            }
                        }

                    }
                    else if (Account.Trim().Length == 10 && !Account.Contains("/"))
                    {
                        string selectquery = "select BRA_CODE,CUS_NUM,CUR_CODE,LED_CODE,SUB_ACCT_CODE from map_acct where map_acc_no = :NubanAccount";


                        using (OracleCommand OraSelect = new OracleCommand(selectquery, OraConn))
                        {

                            OraSelect.CommandType = CommandType.Text;

                            OraSelect.Parameters.Add(":NubanAccount", Account.Trim());
                            if (OraConn.State == ConnectionState.Closed)
                            {
                                OraConn.Open();
                            }
                            using (OraDrSelect = OraSelect.ExecuteReader(CommandBehavior.CloseConnection))
                            {
                                if (OraDrSelect.HasRows == true)
                                {
                                    OraDrSelect.Read();

                                    bra_code = OraDrSelect["BRA_CODE"].ToString();
                                    cus_num = OraDrSelect["CUS_NUM"].ToString();
                                    cur_code = OraDrSelect["CUR_CODE"].ToString();
                                    led_code = OraDrSelect["LED_CODE"].ToString();
                                    sub_acct_code = OraDrSelect["SUB_ACCT_CODE"].ToString();
                                    return string.Concat(bra_code, "/", cus_num, "/", cur_code, "/", led_code, "/", sub_acct_code);

                                    //string BranchCode = GetBankCardReader.GetInt32(0).ToString();
                                    //string CusNum = GetBankCardReader.GetInt64(1).ToString();
                                    //string CurCode = GetBankCardReader.GetInt32(2).ToString();
                                    //string LedgerCode = GetBankCardReader.GetInt32(3).ToString();
                                    //string SubAcctCode = GetBankCardReader.GetInt32(4).ToString();

                                    //return string.Concat(BranchCode, "/", CusNum, "/", CurCode, "/", LedgerCode, "/", SubAcctCode);

                                }
                                else
                                {
                                   // Log.Instance.Fatal("Cannot get nuban");
                                    return "-2";
                                }
                            }
                        }

                    }
                    else
                    {
                       // Log.Instance.Fatal("Not A valid Account");
                        return "Not A valid Account";
                    }
                }
            }
            catch (Exception ex)
            {
               // Log.Instance.Fatal(ex, "Exception");
                return "-1";
            }
            finally
            {

            }
        }





        public string PostToBasis_OverDraw(string accountFrom, string accountTo, decimal Tra_amt, int Expl_code, string remarks,  int DocNum)
        {

            string result1 = string.Empty;
            long result2 = -200;
            long result3 = -200;

            if (accountFrom.Contains("/"))
            {
                accountFrom = ConvertAccountToPadded(accountFrom.Trim(), "/");
            }
            else
            {
                accountFrom = ConvertAccountOldorNUBAN(accountFrom);
                accountFrom = ConvertAccountToPadded(accountFrom.Trim(), "/");
            }


            if (accountTo.Contains("/"))
            {
                accountTo = ConvertAccountToPadded(accountTo.Trim(), "/");
            }
            else
            {
                accountTo = ConvertAccountOldorNUBAN(accountTo);
                accountTo = ConvertAccountToPadded(accountTo.Trim(), "/");
            }

            if (remarks.Length > 170)
            {
                remarks = remarks.Substring(0, 170);
            }
            remarks = remarks.PadRight(170, ' ');
            remarks = remarks + DateTime.Now.Ticks;

            using (OracleConnection oraconn = new OracleConnection(ConfigurationManager.AppSettings["BASISConString_eone"]))
            {
                OracleTransaction transaction;
                if (oraconn.State == ConnectionState.Closed)
                {
                    oraconn.Open();
                }
                transaction = oraconn.BeginTransaction(IsolationLevel.ReadCommitted);
                try
                {
                    OracleCommand oracomm = oraconn.CreateCommand();
                    oracomm.CommandType = CommandType.StoredProcedure;
                    oracomm.CommandTimeout = 60;

                            
                    oracomm.Transaction = transaction;
                    oracomm.CommandText = "EONEPKG.GTBPBSC0_FULL";

                    oracomm.Parameters.Add("INP_ACCT_FROM", OracleDbType.Varchar2, 21).Value = accountFrom;
                    oracomm.Parameters.Add("INP_ACCT_TO", OracleDbType.Varchar2, 21).Value = accountTo;
                    oracomm.Parameters.Add("INP_TRA_AMT", OracleDbType.Decimal, 20).Value = Tra_amt;
                    oracomm.Parameters.Add("INP_EXPL_CODE", OracleDbType.Int32, 15).Value = Expl_code;
                    oracomm.Parameters.Add("INP_REMARKS", OracleDbType.Varchar2, 200).Value = remarks;
                    oracomm.Parameters.Add("inp_rqst_code", OracleDbType.Varchar2, 15).Value = "32";
                    oracomm.Parameters.Add("INP_MAN_APP1", OracleDbType.Int32, 15).Value = 9300;
                    oracomm.Parameters.Add("inp_tell_id", OracleDbType.Int32, 15).Value = 9938;
                    oracomm.Parameters.Add("INP_PERIOD", OracleDbType.Int32, 15).Value = 0;
                    oracomm.Parameters.Add("INP_BNK_CODE", OracleDbType.Int32, 15).Value = 0;
                    oracomm.Parameters.Add("inp_doc_num", OracleDbType.Int32, 15).Value = DocNum;
                    oracomm.Parameters.Add("INP_DOC_ALP", OracleDbType.Varchar2, 200).Value = "FC";
                    oracomm.Parameters.Add("out_tra_seq1", OracleDbType.Int32, 15).Direction = ParameterDirection.Output;
                    oracomm.Parameters.Add("inp_tra_seq1", OracleDbType.Int32, 15).Direction = ParameterDirection.Output;
                    oracomm.Parameters.Add("INP_ORIGT_BRA_CODE", OracleDbType.Int32, 15).Value = 999;
                    oracomm.Parameters.Add("out_return_status", OracleDbType.Varchar2, 100).Direction = ParameterDirection.Output;
                    oracomm.ExecuteNonQuery();
                    result1 = oracomm.Parameters["OUT_RETURN_STATUS"].Value.ToString();

                    if (result1.Trim().CompareTo("@ERR7@") == 0 || result1.Trim().CompareTo("@ERR19@") == 0)
                    {
                        try
                        {
                            result2 = Convert.ToInt64(oracomm.Parameters["out_tra_seq1"].Value.ToString()); //Originating Transaction Sequence
                            result3 = Convert.ToInt64(oracomm.Parameters["inp_tra_seq1"].Value.ToString()); //Originating Transaction Sequence

                            if (result2 <= 0 || result3 <= 0)
                            {
                                transaction.Rollback();
                                //ErrHandler.WriteError(result1 + " returned from basis but sequence is zero for transaction" + " || Rolled back transaction for: " + Acct_from + "," + Acct_to + "," + Tra_amt.ToString() + "," + origtbraCode + "," + result2 + "," + result3 + "," + transUniqIndenf);
                                return "@ERR-74@";
                            }
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            //ErrHandler.WriteError(ex.Message + " || out_tra_seq1 or inp_tra_seq1 threw error. " + result1 + " || Rolled back transaction for: " + Acct_from + "," + Acct_to + "," + Tra_amt.ToString() + "," + origtbraCode + "," + result2 + "," + result3 + "," + transUniqIndenf);
                            return "@ERR-74@";
                        }

                        transaction.Commit();
                        //ErrHandler.WriteError("Commit operation successful for: " + Acct_from + "," + Acct_to + "," + Tra_amt.ToString() + "," + origtbraCode + "," + result2 + "," + result3 + "," + transUniqIndenf);

                        //if (docAlp.ToUpper().Trim() == "GTCN")
                        //{
                        //    InsertTraSeqTransferFund(channel, result2, result3, docAlp, Tra_amt, transUniqIndenf, debitACC, creditACC);
                        //}

                        //ReportingLogs reportLog = new ReportingLogs();
                        //PostingToBasis_Logs(channel, result2, result3, docAlp, Tra_amt, transUniqIndenf, debitACC, creditACC, ipAddress);


                        return result1;
                    }
                    else
                    {
                        transaction.Rollback();
                        //ErrHandler.WriteError(result1 + " || Rolled back transaction for: " + Acct_from + "," + Acct_to + "," + Tra_amt.ToString() + "," + origtbraCode + "," + result2 + "," + result3 + "," + transUniqIndenf);
                        return result1;
                    }
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    //ErrHandler.WriteError(ex.Message + "|| Rolled back transaction: " + Acct_from + "," + Acct_to + "," + Tra_amt.ToString() + "," + origtbraCode + "," + result2 + "," + result3 + "," + transUniqIndenf);
                    result1 = ex.Message;
                    return result1;
                }
                finally
                {
                    oraconn.Close();
                }
            }
        }





    }
}
