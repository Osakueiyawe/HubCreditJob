﻿using Dapper;
using HUBADVANCEMENTJOB.Model;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HUBADVANCEMENTJOB.Repo
{
    class ATM
    {
        //SELECT  [BALANCE_LIMIT_ACCOUNT],[BALANCE_LIMIT_ACCOUNT_OLDACCOUNT],[BALANCE_LIMIT_AMOUNT],[LIMIT_STATUS] FROM [ATM].[dbo].[HUBADVANCEREQUEST] where LIMIT_STATUS <> 'JUST STARTED' and BALANCE_LIMIT_ACCOUNT_OLDACCOUNT is not null


        public static Func<DbConnection> ConnectionFactory = () => new SqlConnection(ConnectionString.Connection);

        public static class ConnectionString
        {
            public static string Connection = ConfigurationManager.ConnectionStrings["ATMDB"].ConnectionString;
        }



        public List<HUBADVANCEREQUEST> GETALLHUBADVANCECUSTOMERS()
        {

            var sql = "SELECT  [TRANSACTIONID],[CUSTOMER_ID],[BALANCE_LIMIT_ACCOUNT],[BALANCE_LIMIT_ACCOUNT_OLDACCOUNT],[BALANCE_LIMIT_AMOUNT],[LIMIT_STATUS] FROM [ATM].[dbo].[HUBADVANCEREQUEST] where LIMIT_STATUS <> 'JUST STARTED' and BALANCE_LIMIT_ACCOUNT_OLDACCOUNT is not null";

            using (var connection = ConnectionFactory())
            {
                connection.Open();

                var invoices = connection.Query<HUBADVANCEREQUEST>(sql).ToList();

                connection.Close();

                return invoices;
            }
        }


        public void BulkInsert(DataTable modified)
        {
            using (var connection = new SqlConnection(ConnectionString.Connection) )
            {

                SqlBulkCopy bulkCopy =
                    new SqlBulkCopy
                    (
                    connection,
                    SqlBulkCopyOptions.TableLock |
                    SqlBulkCopyOptions.FireTriggers |
                    SqlBulkCopyOptions.UseInternalTransaction,
                    null
                    );

                // set the destination table name
                bulkCopy.DestinationTableName = "HUBREQUESTDUMP";
                connection.Open();

                // write the data in the "dataTable"
                bulkCopy.WriteToServer(modified);
                connection.Close();
            }
        }

        internal object InsertOrUpdateAndChange(DataRow item)
        {
            var sql = "INSERT ";

            using (var connection = ConnectionFactory())
            {
                connection.Open();

                var invoices = connection.Query<HUBADVANCEREQUEST>(sql).ToList();

                connection.Close();

                return invoices;
            }
        }

        internal decimal GetAmoutFor(long? cUSTOMER_ID)
        {
            var sql = "SELECT [REPAYMENT_AMOUNT]  FROM [ATM].[dbo].[HubAdvanceRepayment] where CUSTOMERID = @CUSTOMERID";

            using (var connection = ConnectionFactory())
            {
                connection.Open();

                var invoices = connection.ExecuteScalar<decimal>(sql,  new { CUSTOMERID = cUSTOMER_ID });

                connection.Close();

                return invoices;
            }
        }

        internal int UpdateCustomerBalanceLimit(long? cUSTOMER_ID)
        {
            var sql = "UPDATE HubAdvanceRepayment set [REPAYMENT_AMOUNT] = 0 where CUSTOMERID = @CUSTOMERID";

            using (var connection = ConnectionFactory())
            {
                connection.Open();

                var invoices = connection.Execute(sql, new { CUSTOMERID = cUSTOMER_ID });

                connection.Close();

                return invoices;
            }
        }
    }
}
